from django.contrib import admin
from django.urls import path, include
from banking import views
from django.contrib.auth import views as auth_view

urlpatterns = [
    path("", views.index, name='index'),
    path("contact", views.contact, name='contact'),
    path('register/', views.register, name="register"),
	path('login/', auth_view.LoginView.as_view(template_name='login.html'), name="login"),
    path('logout/', views.logoutUser, name="logout"),
    
    
]