
from django.db import models


class Contact(models.Model):
    firstname = models.CharField(max_length=120)
    lastname = models.CharField(max_length=120)
    email = models.EmailField(max_length=50)
    problem = models.TextField()
    date = models.DateTimeField()



       


