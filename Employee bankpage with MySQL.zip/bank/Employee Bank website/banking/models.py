from unittest.util import _MAX_LENGTH
from django.db import models

class Contact(models.Model):
    firstname = models.CharField(max_length=120)
    lastname = models.CharField(max_length=120)
    email = models.EmailField(max_length=50)
    problem = models.TextField()
    date = models.DateTimeField()

    class Meta:
        db_table = "contact"


class Registration(models.Model):
    fullname = models.CharField(max_length=20)
    address = models.CharField(max_length=30)
    email = models.EmailField(max_length=50)
    mobile = models.IntegerField(max_length=10)
    password = models.CharField(max_length=20)

    class Meta:
        db_table = "register"



       


