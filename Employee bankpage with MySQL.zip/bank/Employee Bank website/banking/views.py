
from django.shortcuts import redirect, render, HttpResponse
from datetime import datetime
from banking.models import Contact, Registration
from django.contrib import messages

def index(request):
    return render(request, 'nava.html')

def contact(request):
    if request.method == "POST":
        firstname = request.POST.get('firstname')
        lastname = request.POST.get('lastname')
        email = request.POST.get('email')
        problem = request.POST.get('problem')
        contact = Contact(firstname=firstname,lastname=lastname, email=email, problem = problem, date = datetime.today())
        contact.save()
        print(firstname)
    return render(request, 'contact.html')


def login(request):
    return render(request, 'login.html')

def register(request):
    if request.method == "POST":
        fullname = request.POST.get('fullname')
        address = request.POST.get('address')
        email = request.POST.get('email')
        mobile = request.POST.get('mobile')
        password = request.POST.get('password')
        cpassword = request.POST.get('cpassword')
        if password == cpassword:
            register = Registration(fullname=fullname, address=address, email=email, mobile=mobile,password=password) 
            register.save()
            return redirect('http://127.0.0.1:8000/login')
            
        else:
             messages.error(request, "There is some error try again")



    return render(request, 'register.html')