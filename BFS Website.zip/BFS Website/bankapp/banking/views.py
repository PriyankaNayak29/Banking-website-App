
from django.shortcuts import redirect, render, HttpResponse
from datetime import datetime
from banking.models import Contact
from django.contrib import messages
from .forms import UserRegisterForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout

def index(request):
    return render(request, 'frontpage.html')

@login_required()
def contact(request):
    if request.method == "POST":
        firstname = request.POST.get('firstname')
        lastname = request.POST.get('lastname')
        email = request.POST.get('email')
        problem = request.POST.get('problem')
        contact = Contact(firstname=firstname,lastname=lastname, email=email, problem = problem, date = datetime.today())
        contact.save()
        print(firstname)
    return render(request, 'contact.html')






def register(request):
    if request.method == "POST":
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Hi {username}, your account was created successfully')
            return redirect('index')
    else:
        form = UserRegisterForm()

    return render(request, 'register.html', {'form': form})


def logoutUser(request):
	logout(request)
	return redirect('index')
	